//
//  SPROUT_PrjTests.h
//  SPROUT_PrjTests
//
//  Created by Nguyen Chi Cong on 8/2/12.
//  Copyright (c) 2012 BKHN. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface SPROUT_PrjTests : SenTestCase

@end
