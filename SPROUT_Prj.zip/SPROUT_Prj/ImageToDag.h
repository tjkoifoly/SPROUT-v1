//
//  ImageToDag.h
//  DragDrop
//
//  Created by Nguyen Chi Cong on 8/1/12.
//  Copyright (c) 2012 BKHN. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ImageToDag.h"

@interface ImageToDag : UIView
{
    CGPoint currentPoint;
}


@end
