//
//  ViewPhotoInSproutViewController.h
//  SPROUT_Prj
//
//  Created by Nguyen Chi Cong on 8/3/12.
//  Copyright (c) 2012 BKHN. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewPhotoInSproutViewController : UIViewController

@property (strong, nonatomic) NSArray *listImages;

-(IBAction)back:(id)sender;
-(IBAction)preivousImage:(id)sender;
-(IBAction)nextImage:(id)sender;

@end
