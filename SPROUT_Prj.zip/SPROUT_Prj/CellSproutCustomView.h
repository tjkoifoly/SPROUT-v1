//
//  CellSproutCustomView.h
//  SPROUT_Prj
//
//  Created by Nguyen Chi Cong on 8/2/12.
//  Copyright (c) 2012 BKHN. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellSproutCustomView : UITableViewCell


@property (strong, nonatomic) IBOutlet UIButton *sproutInfo;
@property (strong, nonatomic) IBOutlet UILabel *sproutInfoLabel;


@end
