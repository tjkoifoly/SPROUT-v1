//
//  LoadingViewController.h
//  SPROUT_Prj
//
//  Created by Nguyen Chi Cong on 8/23/12.
//  Copyright (c) 2012 BKHN. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoadingViewController : UIViewController

@end
