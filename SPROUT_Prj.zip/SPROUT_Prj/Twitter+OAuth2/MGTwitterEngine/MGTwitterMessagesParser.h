//
//  MGTwitterMessagesParser.h
//  MGTwitterEngine
//
//  Created by Matt Gemmell on 19/02/2008.
//  Copyright 2008 Instinctive Code.
//

#import "MGTwitterEngineGlobalHeader.h"

#import "MGTwitterStatusesParser.h"

@interface MGTwitterMessagesParser : MGTwitterStatusesParser {

}

@end
