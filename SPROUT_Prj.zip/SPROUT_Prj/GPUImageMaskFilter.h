#import "GPUImageFilter.h"

@interface GPUImageMaskFilter : GPUImageFilter

@end
