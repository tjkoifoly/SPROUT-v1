#import "GPUImageFilterGroup.h"

@interface GPUImageAdaptiveThresholdFilter : GPUImageFilterGroup

@end
