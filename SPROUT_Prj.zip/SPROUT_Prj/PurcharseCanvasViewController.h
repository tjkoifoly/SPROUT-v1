//
//  PurcharseCanvasViewController.h
//  SPROUT_Prj
//
//  Created by Nguyen Chi Cong on 8/3/12.
//  Copyright (c) 2012 BKHN. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PurcharseCanvasViewController : UIViewController

-(IBAction)goToHome:(id)sender;
-(IBAction)chooseCanvas:(id)sender;

@end
