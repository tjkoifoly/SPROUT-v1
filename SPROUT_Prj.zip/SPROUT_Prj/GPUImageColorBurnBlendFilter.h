#import "GPUImageTwoInputFilter.h"

@interface GPUImageColorBurnBlendFilter : GPUImageTwoInputFilter
{
}

@end
