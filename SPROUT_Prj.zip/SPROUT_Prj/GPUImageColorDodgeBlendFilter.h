#import "GPUImageTwoInputFilter.h"

@interface GPUImageColorDodgeBlendFilter : GPUImageTwoInputFilter
{
}

@end
